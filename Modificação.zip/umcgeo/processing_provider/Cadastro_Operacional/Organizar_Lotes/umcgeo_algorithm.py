from qgis.PyQt.QtCore import QCoreApplication,QSettings
from qgis.core import QgsProcessingAlgorithm
from .Organizadorlotes import OrganizadorDeLotes
from .OrganizadorLotesdialog import OrganizadorDeLotesDialog
from qgis.utils import iface as global_iface
from PyQt5.QtGui import QIcon
import os
from qgis.PyQt.QtWidgets import QAction, QMessageBox


class bAlgorithm(QgsProcessingAlgorithm):
    def __init__(self, iface=None):
        super().__init__()
        # Se não receber iface, tenta pegar o global
        self.iface = iface if iface else global_iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dlg = None
        self.first_start = True
        self.actions = []

        # Carregar tradução
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', f'OrganizadorDeLotes_{locale}.qm')
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

    def tr(self, message):
        return QCoreApplication.translate('OrganizadorDeLotes', message)

       
    def initAlgorithm(self, config):
        """
        Here we define the inputs and output of the algorithm, along
        with some other properties.
        """

        # We add the input vector features source. It can have any kind of
        # geometry.
      

        # We add a feature sink in which to store our processed features (this
        # usually takes the form of a newly created vector layer when the
        # algorithm is run in QGIS).
    pass

    def test(self):
        ins_quadra = self.dlg.spinInsQuadra.value()
        QMessageBox.warning(self.dlg, "Aviso", f"Numero Quadra{ins_quadra}")

    def processAlgorithm(self, parameters, context, feedback):
        """Abre o diálogo do Qt Designer"""
        if self.first_start:
            self.first_start = False
            self.dlg = OrganizadorDeLotesDialog()
            self.dlg.btnExecutar.clicked.connect(self.test)
        self.dlg.show()
        if hasattr(self.dlg, 'exec_'):
            self.dlg.exec_()
        return {}

    def name(self):
        return 'orgaLote'

    def displayName(self):
        return self.tr('Organizador Lotes')

    def group(self):
        return self.tr('Ferrame')

    def groupId(self):
        return 'umc'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)
    
    def icon(self):
        return QIcon(os.path.join(os.path.dirname(__file__),'..','img','cadastre.png'))

    def createInstance(self):
        return bAlgorithm(self.iface)
